package net.techvision.model;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.common.reflection.java.generics.TypeEnvironmentFactory;

import javassist.expr.Instanceof;

import java.util.Scanner;

public class DBAction {
	
	Session session;
	Session getSession()
	{
		SessionFactory sessFact = HibernateUtil.getSessionFactory();
		Session sess = sessFact.getCurrentSession();	
		return sess;
	}
	public void CreateData(String n, String mn, String add)
	{

		session = getSession();
		org.hibernate.Transaction tr = session.beginTransaction();
		
		Employee emp = new Employee();
		emp.setEmpName(n);
		emp.setEmpMobileNos(mn);
		emp.setEmpAddress(add);
		session.save(emp);
		
		tr.commit();
		System.out.println("Successfully inserted");
		
	}
	public void ShowData()
	{
		session = getSession();	
		org.hibernate.Transaction tr = session.beginTransaction();
		
		Query query = session.createQuery("from Employee");
		List emps = query.list();
		
		for(int i=0; i<emps.size();i++)
		{
			Employee e = (Employee) emps.get(i);
			
			System.out.println(e.getEmpName()+"\t"+e.getId());
		}
		
		tr.commit();
		
	}
	
	public void UpdateData(String mn)
	{
		session = getSession();	
		org.hibernate.Transaction tr = session.beginTransaction();
		
		Scanner sc =new Scanner(System.in);
		String n,mnn,add;
		String queryString = "from Employee where empMobileNos ="+mn;
		Query query = session.createQuery(queryString);
		List emps = query.list();
		
			Employee e = (Employee) emps.get(0);
			System.out.println(e.getEmpName()+"\t"+e.getId());
		
		
		
		int id =e.getId();
		
		
		System.out.println("enter name :");
		n =sc.next();
		
		System.out.println("enter mobile no :");
		mnn =sc.next();
				
		System.out.println("enter address :");
		add =sc.next();
        
		Employee employee = (Employee)session.get(Employee.class, id);
        employee.setEmpName(n);
        employee.setEmpAddress(add);
        employee.setEmpMobileNos(mnn);
        session.update(employee);
        session.getTransaction().commit();
        System.out.println("Employee Updated!!!");
	}
	public void DeleteData( String n)
	{
		session = getSession();	
		org.hibernate.Transaction tr = session.beginTransaction();
		String hql = "delete from Employee where empMobileNos ="+n;
        Query query1 = session.createQuery(hql);
        int row = query1.executeUpdate();
        if (row == 0){
        System.out.println("Doesn't deleted any row!");
        }
        else{
        System.out.println("Deleted Row: " + row);
		
	  }
	
   }
	
	public void joidex()
	{
		
		System.out.println("before session");
		
		session = getSession();	
		System.out.println("after session");
		
		org.hibernate.Transaction tr = session.beginTransaction();
		System.out.println("after transaction");
		
		/*
		Query query = session.createQuery("select c.customerName, c.customerCity from Customer c "
	                + "left join c.items i");
		
		*/
		Query query = session.createQuery("from Customer");
		//Query query = session.createQuery("select customerId,customerName,customerCity,items  from Customer");
		
		
		System.out.println("after query");
		
		List emps = query.list();
		//, i.itemName,i.price
		System.out.println("after fetch "+emps.size());
		
		for(int i=0; i<emps.size();i++)
		{
			//System.out.println(emps.get(i));
			Customer e = (Customer) emps.get(i);
			
			System.out.println( e instanceof Customer );
			//System.out.println((Item) e.getItems() );
			
			
			System.out.println(e.getCustomerName()+"\t"+e.getCustomerCity()+"\t");
		}
		
	        
	  
	}
}
