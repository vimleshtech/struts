package net.techvision.model;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


/**
 * @author Deepak Kumar 
 * Web: http://www.roseindia.net
 */
public class CreateData {
	public static void main(String[] args) throws Exception {

		// Query query = session.createQuery("from Student"); 
		// select * from student
		//HQL : hibernate query language 
		//we can play with class and object 
		
		String n,mn,add;
		Scanner sc =new Scanner(System.in);
		/*
		System.out.println("enter name :");
		n =sc.nextLine();
		
		System.out.println("enter mobile no :");
		mn =sc.nextLine();
		
		
		System.out.println("enter address :");
		add =sc.nextLine();
		
		
		
		DBAction o =new DBAction();
		o.CreateData(n,mn,add);
		o.ShowData();
		System.out.println("enter mobile no to update data:");
		mn =sc.next();
		o.UpdateData(mn);*/
		DBAction o =new DBAction();
		System.out.println("enter mobile to delete data :");
		//n =sc.nextLine();
		//o.DeleteData(n);
		o.joidex();
		
		
	}

}