package coreExample;
import beans.*;

public class caller {

	public static void main(String[] args) {
		
		
		Calculation obj = new ExtendedCalculation();	
		
		System.out.println(obj.add(11, 22));
		
	System.out.println(obj.validate("test", "pwd"));

	System.out.println(obj.validate("test", "pwd1"));
		
		
		

	}

}
