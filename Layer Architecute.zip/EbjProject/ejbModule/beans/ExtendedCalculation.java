package beans;

public class ExtendedCalculation implements Calculation {

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
		
	}

	//jdbc
	
	@Override
	public String validate(String uname, String pwd) {
		
		if(uname.equals("test") && pwd.equals("pwd"))
			return "sucess";
		else
			return "fail";
	}

	
}
