package beans;

public interface Calculation {


	public int add(int a, int b);
	public String validate(String uname, String pwd);
	
}
